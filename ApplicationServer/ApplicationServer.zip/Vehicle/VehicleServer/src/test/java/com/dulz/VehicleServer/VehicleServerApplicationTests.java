package com.dulz.VehicleServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
