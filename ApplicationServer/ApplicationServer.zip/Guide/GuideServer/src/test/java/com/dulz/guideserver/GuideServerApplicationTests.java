package com.dulz.guideserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuideServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
