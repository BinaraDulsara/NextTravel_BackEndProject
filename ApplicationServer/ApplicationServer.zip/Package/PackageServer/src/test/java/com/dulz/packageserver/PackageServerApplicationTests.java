package com.dulz.packageserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackageServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
