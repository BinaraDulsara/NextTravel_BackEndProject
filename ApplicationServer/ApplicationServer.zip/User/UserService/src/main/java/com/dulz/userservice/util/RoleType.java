package com.dulz.userservice.util;

public enum RoleType {
    ADMIN,USER,CUSTOMER
}
